-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Nov 18, 2018 at 11:21 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `academy`
--

-- --------------------------------------------------------

--
-- Table structure for table `Course`
--

CREATE TABLE `Course` (
  `CourseID` int(11) UNSIGNED NOT NULL,
  `CourseName` text,
  `MajorID` int(11) DEFAULT NULL,
  `CourseCode` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Course`
--

INSERT INTO `Course` (`CourseID`, `CourseName`, `MajorID`, `CourseCode`) VALUES
(1, 'Intro to Programming', 1, 'CMP101'),
(2, 'Intro to Database Design', 1, 'CMP306'),
(3, 'Intro To Business Adminstration', 2, 'BIS101'),
(4, 'Business Analysis', 2, 'BIS202'),
(5, 'Intro to Civil Eng', 4, 'CEV101'),
(6, 'Construction Management', 4, 'CEV400');

-- --------------------------------------------------------

--
-- Table structure for table `Enrolment`
--

CREATE TABLE `Enrolment` (
  `EnrollID` int(11) UNSIGNED NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `CourseID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Enrolment`
--

INSERT INTO `Enrolment` (`EnrollID`, `StudentID`, `CourseID`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 3),
(4, 5, 3),
(5, 2, 4),
(6, 4, 5);

-- --------------------------------------------------------

--
-- Table structure for table `Major`
--

CREATE TABLE `Major` (
  `MajorID` int(11) NOT NULL,
  `MajorName` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Major`
--

INSERT INTO `Major` (`MajorID`, `MajorName`) VALUES
(1, 'computer'),
(2, 'business'),
(3, 'ELECTRICAL'),
(4, 'CIVIL ENG');

-- --------------------------------------------------------

--
-- Table structure for table `Student`
--

CREATE TABLE `Student` (
  `StudentID` int(11) NOT NULL,
  `StudentName` text NOT NULL,
  `StudentAge` int(11) NOT NULL,
  `StudentMajor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Student`
--

INSERT INTO `Student` (`StudentID`, `StudentName`, `StudentAge`, `StudentMajor`) VALUES
(1, 'mosaab', 30, 1),
(2, 'AMR', 19, 2),
(3, 'abdallah', 18, 0),
(4, 'asma', 20, 4),
(5, 'RAFA', 20, 2),
(6, 'mosaab', 40, 3),
(7, 'ahmed', 70, 4),
(14, 'aya', 20, 2),
(15, 'abdelrahman', -100, 3),
(16, 'foud', 18, 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Course`
--
ALTER TABLE `Course`
  ADD PRIMARY KEY (`CourseID`);

--
-- Indexes for table `Enrolment`
--
ALTER TABLE `Enrolment`
  ADD PRIMARY KEY (`EnrollID`);

--
-- Indexes for table `Major`
--
ALTER TABLE `Major`
  ADD PRIMARY KEY (`MajorID`);

--
-- Indexes for table `Student`
--
ALTER TABLE `Student`
  ADD PRIMARY KEY (`StudentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Course`
--
ALTER TABLE `Course`
  MODIFY `CourseID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `Enrolment`
--
ALTER TABLE `Enrolment`
  MODIFY `EnrollID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `Student`
--
ALTER TABLE `Student`
  MODIFY `StudentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
