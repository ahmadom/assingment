angr u<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class student_model extends CI_Model {


  function __construct() {
    parent::__construct();
  }

  function get_all_students() {
    $sql = "select * from student inner join
    major on student.studentMajor = major.majorID";
    $query = $this->db->query($sql);
    $results = array();
    foreach ($query->result() as $result) {
      $results[] = $result;
    }
    return $results;
  }
  function searchStudentByName($studentName) {
    $sql = "select * from student inner join major on student.studentMajor = major.majorID where studentName LIKE '%{$studentName}%'";
    $query = $this->db->query($sql, $studentName);
    $results = array();
    foreach ($query->result() as $result) {
      $results[] = $result;
    }
    return $results;
  }
  function addStudent() {
    $data = array(
          'StudentName' => $this->input->post("studentName"),
          'StudentAge' => $this->input->post("studentAge"),
          'StudentMajor' => $this->input->post("studentMajor")
  );

  $this->db->insert('Student', $data);
  return 1;
  }
  function getMajors() {
    //$query = $this->db->get('Student');
    $sql = "select * from major";
    //$this->db->select('*');
    //$this->db->from('Student');
    //$this->db->join('Major', 'Student.StudentMajor = Major.MajorID');
    //$query = $this->db->get();
    $query = $this->db->query($sql);
    $results = array();
    foreach ($query->result() as $result) {
      $results[] = $result;
    }
    return $results;
  }

}
