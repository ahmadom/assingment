<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Academy extends CI_Controller {

	public function __construct() {
    parent::__construct();

    $this->load->model('student_model');
  }

	public function index()
	{
		$this->load->view('academy_main');
	}

	public function showallstudents()
	{
		$all_students = $this->student_model->get_all_students();

    $data = array();
    $data['students'] = $all_students;
		$this->load->view('show_students',$data);
	}

	public function search_student_by_name()
	{
		if($this->input->post("studentName"))
		{
			$result = $this->student_model->searchStudentByName($this->input->post("studentName"));
	    $data = array();
	    $data['student'] = $result;
			$this->load->view('search_student_by_name',$data);
		}
		else
		{
			$this->load->view('search_student_by_name');
		}

	}
	public function add_student()
	{
		if($this->input->post("studentName") || $this->input->post("studentAge") || $this->input->post("studentMajor"))
		{
			$result = $this->student_model->addStudent();
			$data = array();
			$data['result'] = $result;
			$this->load->view('add_student',$data);
		}
		else
		{
			$result = $this->student_model->getMajors();
			$data = array();
			$data['majorList'] = $result;
			$this->load->view('add_student',$data);
		}

	}
}
