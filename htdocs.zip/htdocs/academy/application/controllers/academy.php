<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class academy extends CI_controller{

  public function __construct() {
    parent::__construct();
    $this->load->model('student_model');
}

    public function index()
  {
    $this->load->view('academy_main');
}
public function showallstudents()
{
  $all_students = $this->student_model->get_all_students();
  $data = array();
  $data ['students']= $all_students;
  $this->load->view('show_students',$data);
}
}
?>
